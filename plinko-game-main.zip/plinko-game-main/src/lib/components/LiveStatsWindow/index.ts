export { default } from './LiveStatsWindow.svelte';
