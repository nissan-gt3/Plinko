// The benchmark page is for development only, so hidden from production build
export const prerender = false;
